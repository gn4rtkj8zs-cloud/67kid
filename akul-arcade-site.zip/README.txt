Akul Arcade

Upload index.html to any static website host such as GitHub Pages, Netlify, or Cloudflare Pages.
The game embeds require internet access and may be blocked by a school/network administrator.
